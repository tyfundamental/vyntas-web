/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { View } from './types';
import Header from './components/Header';
import Hero from './components/Hero';
import ScienceSection from './components/ScienceSection';
import ProtocolSection from './components/ProtocolSection';
import MagazineSection from './components/MagazineSection';
import AboutSection from './components/AboutSection';
import Footer from './components/Footer';
import NewsletterModal from './components/NewsletterModal';
import ComparisonDrawer from './components/ComparisonDrawer';

export default function App() {
  const [activeView, setActiveView] = useState<View>(View.CIENCIA);
  const [newsletterOpen, setNewsletterOpen] = useState(false);
  const [comparisonOpen, setComparisonOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('');

  // Handle auto-detection of current section while scrolling (highly premium feedback)
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 200;

      const sections = [
        { key: View.CIENCIA, id: 'ciencia' },
        { key: View.PROTOCOLOS, id: 'protocolos' },
        { key: View.REVISTA, id: 'revista' },
        { key: View.NOSOTROS, id: 'nosotros' }
      ];

      for (const section of sections) {
        const element = document.getElementById(section.id);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveView(section.key);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleOpenComparison = (category: string) => {
    setSelectedCategory(category);
    setComparisonOpen(true);
  };

  const handleOpenNewsletter = () => {
    setNewsletterOpen(true);
  };

  const handleScrollToId = (id: string, view: View) => {
    setActiveView(view);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div id="longevity-app" className="bg-zinc-50 min-h-screen text-zinc-900 selection:bg-zinc-900 selection:text-white">
      {/* Background Ambience Spot */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[600px] bg-[radial-gradient(circle_at_top,rgba(0,0,0,0.03)_0%,transparent_60%)] pointer-events-none" />

      {/* Header and Floating Navigation */}
      <Header 
        activeView={activeView}
        onViewChange={setActiveView}
        onOpenNewsletter={handleOpenNewsletter}
      />

      {/* Main Flow Layout */}
      <main className="relative min-h-screen">
        
        {/* HERO: Vive más. Vive mejor. */}
        <Hero 
          onScrollToScience={() => handleScrollToId('ciencia', View.CIENCIA)}
          onOpenNewsletter={handleOpenNewsletter}
        />

        {/* 1. CIENCIA SECTION */}
        <ScienceSection />

        {/* 2. PROTOCOLOS SECTION (previously TIENDA, reordered to be educational, non-commercial) */}
        <ProtocolSection />

        {/* 3. REVISTA SECTION */}
        <MagazineSection />

        {/* 4. NOSOTROS SECTION (+ PREGUNTAS / FAQS as sub-section) */}
        <AboutSection />

      </main>

      {/* FOOTER: Premium hairline layout with FAQs shortcuts and affiliate disclaimers */}
      <Footer 
        onNavClick={setActiveView}
        onOpenNewsletter={handleOpenNewsletter}
      />

      {/* MODAL: Newsletter email capture capture details */}
      <NewsletterModal 
        isOpen={newsletterOpen}
        onClose={() => setNewsletterOpen(false)}
      />

      {/* DRAWER: Affiliate comparisons for recommended compounds and HPLC certificates */}
      <ComparisonDrawer 
        isOpen={comparisonOpen}
        onClose={() => setComparisonOpen(false)}
        selectedCategory={selectedCategory}
      />
    </div>
  );
}
