import React, { useState } from 'react';
import { View } from '../types';
import { Menu, X, Shield, Activity } from 'lucide-react';

interface HeaderProps {
  activeView: View;
  onViewChange: (view: View) => void;
  onOpenNewsletter: () => void;
}

export default function Header({ activeView, onViewChange, onOpenNewsletter }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { key: View.CIENCIA, label: 'CIENCIA' },
    { key: View.PROTOCOLOS, label: 'PROTOCOLOS' },
    { key: View.REVISTA, label: 'REVISTA' },
    { key: View.NOSOTROS, label: 'NOSOTROS' },
  ];

  const handleNavClick = (view: View) => {
    onViewChange(view);
    setMobileMenuOpen(false);

    // Smooth scroll support
    const element = document.getElementById(view.toLowerCase());
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white/90 backdrop-blur-md border-b border-zinc-200 border-opacity-90 shadow-xs">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Brand Logo and Title */}
        <div 
          onClick={() => handleNavClick(View.CIENCIA)}
          className="flex items-center gap-2.5 cursor-pointer group"
        >
          <div className="h-8 w-8 border border-zinc-200 bg-emerald-50 text-emerald-700 flex items-center justify-center transition-all group-hover:bg-emerald-100 group-hover:border-emerald-300 rounded-sm">
            <Activity size={15} className="shrink-0 stroke-[2.5]" />
          </div>
          <span className="text-sm font-black tracking-[0.3em] text-zinc-900 font-sans uppercase">
            VYNTAS
          </span>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6 lg:space-x-8 text-xs font-mono tracking-[0.25em] text-zinc-500 select-none font-bold">
          {navItems.map((item, idx) => (
            <React.Fragment key={item.key}>
              <button
                id={`nav-${item.key.toLowerCase()}`}
                onClick={() => handleNavClick(item.key)}
                className={`py-1 cursor-pointer transition-colors hover:text-zinc-950 uppercase relative font-bold ${
                  activeView === item.key ? 'text-zinc-950 font-extrabold' : ''
                }`}
              >
                {item.label}
                {activeView === item.key && (
                  <span className="absolute bottom-0 left-0 w-full h-[2px] bg-zinc-900" />
                )}
              </button>
              {idx < navItems.length && (
                <span className="text-zinc-300 font-light pointer-events-none select-none">·</span>
              )}
            </React.Fragment>
          ))}
          {/* NEWSLETTER Menu Item */}
          <button
            id="nav-newsletter"
            onClick={() => {
              onOpenNewsletter();
              onViewChange(View.NEWSLETTER);
            }}
            className={`py-1 bg-transparent hover:text-zinc-950 transition-colors cursor-pointer text-zinc-500 font-bold ${
              activeView === View.NEWSLETTER ? 'text-zinc-950 font-extrabold' : ''
            }`}
          >
            NEWSLETTER
          </button>
        </nav>

        {/* Desktop CTA Accent */}
        <div className="hidden md:flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-xs text-zinc-500 font-mono tracking-wider border-r border-zinc-200 pr-4 font-bold">
            <Shield size={13} className="text-emerald-700 shrink-0 mt-0.5" />
            <span>ENLACES VERIFICADOS</span>
          </div>
          <button
            id="header-cta"
            onClick={onOpenNewsletter}
            className="border border-zinc-300 hover:border-zinc-900 px-4 py-1.5 text-xs font-mono tracking-widest text-zinc-700 hover:text-zinc-950 uppercase bg-zinc-50 hover:bg-zinc-100 transition-all duration-300 rounded-sm font-bold shadow-xs cursor-pointer"
          >
            Suscripción Científica
          </button>
        </div>

        {/* Mobile Menu Button */}
        <div className="flex md:hidden items-center">
          <button
            id="mobile-menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="text-zinc-500 hover:text-zinc-950 p-1.5 border border-zinc-200 bg-white"
            aria-label="Menú principal"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-zinc-200 bg-white/95 backdrop-blur-lg">
          <div className="px-6 py-4 flex flex-col space-y-4 text-xs font-mono tracking-[0.2em]">
            {navItems.map((item) => (
              <button
                key={item.key}
                id={`mobile-nav-${item.key.toLowerCase()}`}
                onClick={() => handleNavClick(item.key)}
                className={`py-2 text-left w-full border-b border-zinc-100 pb-2 ${
                  activeView === item.key ? 'text-zinc-950 font-bold pl-1 border-zinc-905' : 'text-zinc-500'
                }`}
              >
                {item.label}
              </button>
            ))}
            <button
              id="mobile-nav-newsletter"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenNewsletter();
                onViewChange(View.NEWSLETTER);
              }}
              className="py-2 text-left w-full border-b border-zinc-100 pb-2 text-zinc-500"
            >
              NEWSLETTER
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
