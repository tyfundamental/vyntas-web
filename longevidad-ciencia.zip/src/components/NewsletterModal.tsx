import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Check, Mail, Shield } from 'lucide-react';

interface NewsletterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function NewsletterModal({ isOpen, onClose }: NewsletterModalProps) {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError('Por favor, introduzca una dirección de correo válida.');
      return;
    }
    setError('');
    setLoading(true);

    // Simulate elite secure delivery signup
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
      setEmail('');
    }, 1200);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            id="newsletter-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/40 backdrop-blur-xs"
          />

          {/* Modal Container */}
          <motion.div
            id="newsletter-modal-box"
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ type: 'spring', duration: 0.4 }}
            className="relative w-full max-w-lg overflow-hidden border border-zinc-200 bg-white p-8 md:p-10 shadow-2xl rounded-none"
          >
            {/* Fine Hairline Decor Corners */}
            <div className="absolute top-0 left-0 w-2.5 h-2.5 border-t border-l border-zinc-400" />
            <div className="absolute top-0 right-0 w-2.5 h-2.5 border-t border-r border-zinc-400" />
            <div className="absolute bottom-0 left-0 w-2.5 h-2.5 border-b border-l border-zinc-400" />
            <div className="absolute bottom-0 right-0 w-2.5 h-2.5 border-b border-r border-zinc-400" />

            {/* Close Button */}
            <button
              id="close-newsletter-btn"
              onClick={onClose}
              className="absolute top-4 right-4 text-zinc-500 hover:text-zinc-955 transition-colors duration-200 p-1 bg-zinc-50 border border-zinc-200 hover:bg-zinc-100"
              aria-label="Cerrar modal"
            >
              <X size={18} />
            </button>

            {!submitted ? (
              <div id="newsletter-form-container">
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex h-10 w-10 items-center justify-center border border-zinc-200 bg-zinc-50 text-zinc-800">
                    <Mail size={16} className="stroke-[2]" />
                  </div>
                  <span className="text-xs tracking-[0.2em] text-zinc-500 font-mono font-bold">CONEXIÓN DIRECTA</span>
                </div>

                <h3 className="text-2xl font-bold text-zinc-900 tracking-tight uppercase mb-3">
                  Boletín de Ciencia de Vanguardia
                </h3>
                <p className="text-sm text-zinc-600 leading-relaxed font-normal mb-6">
                  Únase a nuestra lista selecta de investigadores y personas interesadas en longevidad celular. Reciba revisiones sin sesgo comercial de nuevos papers, patentes emergentes y actualizaciones moleculares críticas.
                </p>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="relative">
                    <input
                      id="newsletter-email-input"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="DIRECCIÓN DE CORREO ELECTRÓNICO"
                      className="w-full bg-zinc-50 border border-zinc-300 text-sm px-4 py-3.5 text-zinc-900 tracking-wider placeholder:text-zinc-400 focus:outline-none focus:border-zinc-500 focus:bg-white transition-all uppercase font-mono rounded-none"
                      disabled={loading}
                    />
                  </div>

                  {error && (
                    <p className="text-xs tracking-wider text-red-600 font-mono">{error}</p>
                  )}

                  <button
                    id="submit-newsletter-btn"
                    type="submit"
                    className="w-full bg-zinc-900 text-white hover:bg-zinc-850 transition-all duration-300 text-xs sm:text-sm tracking-[0.25em] font-bold py-4 border border-zinc-900 flex items-center justify-center gap-2 font-mono cursor-pointer shadow-md"
                    disabled={loading}
                  >
                    {loading ? (
                      <span className="inline-block animate-pulse">SINCRO DE SERVIDOR...</span>
                    ) : (
                      <span>SUSCRIBIRSE AL PROTOCOLO →</span>
                    )}
                  </button>
                </form>

                <div className="mt-8 pt-6 border-t border-zinc-200 flex items-center justify-between text-xs text-zinc-500 font-mono font-bold">
                  <div className="flex items-center gap-1">
                    <Shield size={12} className="text-emerald-700" />
                    <span>ENCRIPTADO CERO PROPAGANDA</span>
                  </div>
                  <span>LOTE: C2026-X</span>
                </div>
              </div>
            ) : (
              <motion.div
                id="newsletter-success-container"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-6"
              >
                <div className="mx-auto flex h-14 w-14 items-center justify-center border border-zinc-250 bg-emerald-50 text-emerald-700 rounded-none mb-4">
                  <Check size={24} className="stroke-[2.5]" />
                </div>
                <h3 className="text-xl font-bold text-zinc-900 tracking-tight uppercase mb-2">
                  CONEXIÓN ESTABLECIDA
                </h3>
                <p className="text-sm text-zinc-600 leading-relaxed font-normal max-w-sm mx-auto mb-6">
                  Su dirección ha sido incorporada a las entregas de divulgación avanzada. Enviaremos el primer informe cromatográfico y de papers próximamente de forma exclusiva.
                </p>
                <button
                  id="success-newsletter-close-btn"
                  onClick={onClose}
                  className="bg-zinc-900 text-white hover:bg-zinc-800 transition-all duration-300 text-xs tracking-[0.2em] font-bold px-6 py-3.5 font-mono cursor-pointer shadow-md"
                >
                  VOLVER AL SITIO
                </button>
              </motion.div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
